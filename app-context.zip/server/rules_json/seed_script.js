import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'
import { pool } from '../db/index.js'

const client = await pool.connect()

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)


const RULE_FILES = [
  'whats_working.rules.json',
  'whats_risky.rules.json',
  'how_to_proceed.rules.json'
]

async function seedRules() {
  for (const file of RULE_FILES) {
    const fullPath = path.join(__dirname, file)
    const data = JSON.parse(fs.readFileSync(fullPath, 'utf-8'))

    for (const rule of data.rules) {
      await client.query(
        `
        INSERT INTO rules (id, section, checkpoint, priority, conditions, copy)
        VALUES ($1, $2, $3, $4, $5, $6)
        ON CONFLICT (id) DO NOTHING
        `,
        [
          rule.id,
          data.section,
          rule.checkpoint, // <-- explicit
          rule.priority,
          JSON.stringify(rule.when),
          rule.copy
        ]
      )
      console.log(`Inserted rule with ID: ${rule.id}`)
    }
  }
}

await seedRules()
client.release()
console.log('Seeding completed.')